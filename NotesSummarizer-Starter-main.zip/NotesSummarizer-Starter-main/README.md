# AI Notes App

This is a simple notes app, which can summarize notes. It uses Gemini Pro model, developed by Google.
