package com.example.ai_notes_app_simple

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
